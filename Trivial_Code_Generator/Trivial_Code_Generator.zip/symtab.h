#define NSYMS 20

struct symtab
{
    char* name;
    char* token;
    char* type;
    char* value;
    char* location;
} symtab[NSYMS];